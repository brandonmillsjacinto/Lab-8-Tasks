//=====[#include guards - begin]===============================================

#ifndef _SD_CARD_H_
#define _SD_CARD_H_


#include <iostream>
#include <fstream>
#include <string>
//=====[Declaration of public defines]=========================================

#define SD_CARD_MAX_FILE_LIST       10
#define SD_CARD_FILENAME_MAX_LENGTH 32
#define SD_CARD_BUFFER_SIZE         512  

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

bool sdCardInit();
bool sdCardWriteFile( const char* fileName, const char* writeBuffer );
bool sdCardReadFile(const std::string& fileName, std::string& readBuffer);


//=====[#include guards - end]=================================================

#endif // _SD_CARD_H_