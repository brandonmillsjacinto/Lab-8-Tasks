//=====[#include guards - begin]===============================================

#ifndef _AUDIO_H_
#define _AUDIO_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void audioInit();

//=====[#include guards - end]=================================================

#endif // _AUDIO_H_